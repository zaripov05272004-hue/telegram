




import logging
import requests
import asyncio
from datetime import datetime
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage

BOT_TOKEN = "8272236882:AAEgK7j_hUBIoPzdqUCi2tATO2tK3MgJAh8"
OPENWEATHER_API_KEY = "0cd3d7b8722cec1b1e1cf22495aeac35"

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

#  STATE
class CityWeatherState(StatesGroup):
    city = State()

class CurrencyState(StatesGroup):
    usd_amount = State()
    uzs_amount = State()

#


# START
@dp.message(Command("start"))
async def start(message: types.Message):
    await message.answer(
        "Salom 👋\n\n"
        "🌤 /shahar_obhavo — ob-havo\n"
        "💱 /usd_to_uzs — dollar → so‘m\n"
        "💱 /uzs_to_usd — so‘m → dollar"
    )

# OB-HAVO
@dp.message(Command("shahar_obhavo"))
async def ask_city(message: types.Message, state: FSMContext):
    await message.answer("🏙 Shahar nomini kiriting:")
    await state.set_state(CityWeatherState.city)

@dp.message(CityWeatherState.city)
async def get_weather(message: types.Message, state: FSMContext):
    city = message.text.strip()

    try:
        url = (
            "https://api.openweathermap.org/data/2.5/forecast"
            f"?q={city}&units=metric&lang=uz&appid={OPENWEATHER_API_KEY}"
        )

        data = requests.get(url, timeout=10).json()

        if data.get("cod") != "200":
            await message.answer("❌ Shahar topilmadi.")
            await state.clear()
            return

        text = f"🌤 **{city.title()} — 5 KUNLIK OB-HAVO** 🌤\n\n"
        used_dates = set()

        for item in data["list"]:
            date = item["dt_txt"].split(" ")[0]
            if date not in used_dates:
                used_dates.add(date)
                day = datetime.strptime(date, "%Y-%m-%d").strftime("%d-%m-%Y")

                text += (
                    f"📅 {day}\n"
                    f"🌡 {item['main']['temp']}°C\n"
                    f"☁ {item['weather'][0]['description']}\n\n"
                )

            if len(used_dates) == 5:
                break

        await message.answer(text)
        await state.clear()

    except Exception as e:
        await message.answer(f"⚠️ Xatolik: {e}")
        await state.clear()

#USD → UZS
@dp.message(Command("usd_to_uzs"))
async def ask_usd(message: types.Message, state: FSMContext):
    await message.answer("💵 USD miqdorini kiriting:")
    await state.set_state(CurrencyState.usd_amount)

@dp.message(CurrencyState.usd_amount)
async def convert_usd(message: types.Message, state: FSMContext):
    try:
        usd = float(message.text)

        data = requests.get(
            "https://open.er-api.com/v6/latest/USD", timeout=10
        ).json()

        rate = data["rates"]["UZS"]
        uzs = usd * rate

        await message.answer(
            f"💱 **USD → UZS**\n\n"
            f"{usd} USD = {uzs:,.2f} so‘m"
        )
        await state.clear()

    except ValueError:
        await message.answer("❌ Raqam kiriting!")
    except Exception as e:
        await message.answer(f"⚠️ Xatolik: {e}")
        await state.clear()

# ===================== UZS → USD =====================
@dp.message(Command("uzs_to_usd"))
async def ask_uzs(message: types.Message, state: FSMContext):
    await message.answer("💴 UZS miqdorini kiriting:")
    await state.set_state(CurrencyState.uzs_amount)

@dp.message(CurrencyState.uzs_amount)
async def convert_uzs(message: types.Message, state: FSMContext):
    try:
        uzs = float(message.text)

        data = requests.get(
            "https://open.er-api.com/v6/latest/USD", timeout=10
        ).json()

        rate = data["rates"]["UZS"]
        usd = uzs / rate

        await message.answer(
            f"💱 **UZS → USD**\n\n"
            f"{uzs:,.0f} so‘m = {usd:.2f} USD"
        )
        await state.clear()

    except ValueError:
        await message.answer("❌ Raqam kiriting!")
    except Exception as e:
        await message.answer(f"⚠️ Xatolik: {e}")
        await state.clear()

# ===================== RUN =====================
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())


